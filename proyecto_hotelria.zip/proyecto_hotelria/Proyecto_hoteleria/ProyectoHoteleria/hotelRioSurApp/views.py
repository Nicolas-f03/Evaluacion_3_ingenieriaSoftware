from django.shortcuts import render, redirect
from .forms import  reservaForm, habitacionForm, huspedForm
from .models import habitacionModel, reservasModel
from django.contrib.auth.decorators import login_required

# Create your views here.

def index(request):
    return render(request, 'index.html',{})



def registro_reserva(request,id):
    habitacion = habitacionModel.objects.get(pk=id)
    formulario=reservaForm()
    if request.method=='POST':
        formulario=reservaForm(request.POST)
        if formulario.is_valid():
            reserva = formulario.save(commit=False)
            reserva.numero_habitacion_reserva = habitacion
            reserva.save()
            habitacion.estado_habitacion = 'Reservada'
            habitacion.save()
            return redirect('habitaciones')
    data={
        'formulario':formulario
    }
    return render(request, 'registro_reserva.html',data)

@login_required(login_url='/accounts/login/')
def registro_habitacion(request):
    formularios = habitacionForm()
    if request.method=='POST':
        formularios = habitacionForm(request.POST)
        if formularios.is_valid():
            formularios.save()
            return redirect('/habitaciones')
    data={
        'formularios':formularios,
    }
    return render(request, 'registro_habitacion.html', data)

def eliminar_habitacion(request, id):
    habitacion = habitacionModel.objects.get(id=id)
    if request.method == 'POST':
        habitacion.delete()
        return redirect('/habitaciones')
    return render(request, 'eliminar_habitacion.html', {'habitacion': habitacion})

def editar_habitacion(request, id):
    habitacion = habitacionModel.objects.get(id=id)
    if request.method == 'POST':
        formulario = habitacionForm(request.POST, instance=habitacion)
        if formulario.is_valid():
            formulario.save()
            return redirect('/habitaciones')
    else:
        formulario = habitacionForm(instance=habitacion)
    return render(request, 'editar_habitacion.html', {'formulario': formulario, 'habitacion': habitacion})

def habitaciones(request):
    habitaciones = habitacionModel.objects.all()
    data = {
        'habitaciones': habitaciones,
    }
    return render(request, 'habitaciones.html',data)


def reservas(request):
    reservas = reservasModel.objects.all()
    data = {
        'reservas': reservas
    }
    return render(request, 'reservas.html',data)

def registro_huesped(request):
    formulario = huspedForm()
    if request.method == 'POST':
        formulario = huspedForm(request.POST)
        if formulario.is_valid():
            formulario.save()
            return redirect('/habitaciones')
    data = {
        'formulario': formulario
    }
    return render(request, 'registro_huesped.html', data)

def checkin(request,id):
    reservas = reservasModel.objects.get(id=id)
    habitacion_id = reservas.numero_habitacion_reserva
    habitacion = habitacionModel.objects.get(numero_habitacion=habitacion_id.numero_habitacion)
    if request.method == 'POST':
        reservas.estado_reserva = 'Activa'
        reservas.save()
        habitacion.estado_habitacion = 'Ocupada'
        habitacion.save()
    return redirect('/reservas')

def checkout(request,id):
    reservas = reservasModel.objects.get(id=id)
    habitacion_id = reservas.numero_habitacion_reserva
    habitacion = habitacionModel.objects.get(numero_habitacion=habitacion_id.numero_habitacion)
    if request.method == 'POST':
        reservas.estado_reserva = 'Finalizada'
        reservas.save()
        habitacion.estado_habitacion = 'Disponible'
        habitacion.save()
    return redirect('/reservas')

def cancelar_reserva(request, id):
    reserva = reservasModel.objects.get(id=id)
    habitacion_id = reserva.numero_habitacion_reserva
    habitacion = habitacionModel.objects.get(numero_habitacion=habitacion_id.numero_habitacion)
    if request.method == 'POST':
        reserva.estado_reserva = 'Cancelada'
        reserva.save()
        habitacion.estado_habitacion = 'Disponible'
        habitacion.save()
    return redirect('/reservas')

def eliminar_reserva(request, id):
    reserva = reservasModel.objects.get(id=id)
    habitacion_id = reserva.numero_habitacion_reserva
    habitacion = habitacionModel.objects.get(numero_habitacion=habitacion_id.numero_habitacion)
    if request.method == 'POST':
        habitacion.estado_habitacion = 'Disponible'
        habitacion.save()
        reserva.delete()
    return redirect('/reservas')

def huspedes(request):
    huspedes = huspedForm.objects.all()
    data = {
        'huspedes': huspedes
    }
    return render(request, 'huspedes.html',data)