from django.urls import path
from . import views

urlpatterns = [
    path('', views.index,name="inicio"),
    path('inicio/',views.index,name="inicio"),
    path('lista_huespedes/',views.huspedes,name="lista_huespedes"),
    path('habitaciones/',views.habitaciones,name="habitaciones"),
    path('eliminar_habitacion/<int:id>/',views.eliminar_habitacion,name="eliminar_habitacion"),
    path('editar_habitacion/<int:id>/',views.editar_habitacion,name="editar_habitacion"),
    path('reservas/',views.reservas,name="reservas"),
    path('checkin/<int:id>/',views.checkin,name="checkin"),
    path('checkout/<int:id>/',views.checkout,name="checkout"),
    path('cancelar/<int:id>/',views.cancelar_reserva,name="cancelar_reserva"),
    path('eliminar/<int:id>/',views.eliminar_reserva,name="eliminar_reserva"),
    path('registro_Huesped/',views.registro_huesped,name="registro huesped"),
    path('Habitaciones/registroReserva/<int:id>/',views.registro_reserva,name="registro reserva"),
    path('registroHabitacion/',views.registro_habitacion,name="registro habitacion"),
]