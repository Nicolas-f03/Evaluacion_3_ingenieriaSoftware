from django.test import TestCase
from django.urls import reverse

from .models import habitacionModel, huspedModel, reservasModel


class RegistroReservaTests(TestCase):
    def setUp(self):
        self.habitacion = habitacionModel.objects.create(
            numero_habitacion='101',
            precio_habitacion=50000,
        )
        huspedModel.objects.create(
            rut='12345678-9',
            nombre='Huesped de prueba',
            telefono='123456789',
        )

    def test_asigna_la_habitacion_seleccionada_a_la_reserva(self):
        response = self.client.post(
            reverse('registro reserva', args=[self.habitacion.pk]),
            {
                'rut_huesped': '12345678-9',
                'fecha_inicio': '2026-12-01',
                'fecha_termino': '2026-12-03',
            },
        )

        self.assertRedirects(response, reverse('habitaciones'))
        reserva = reservasModel.objects.get()
        self.assertEqual(reserva.numero_habitacion_reserva, self.habitacion)
        self.habitacion.refresh_from_db()
        self.assertEqual(self.habitacion.estado_habitacion, 'Reservada')

    def test_rechaza_fecha_de_termino_anterior_al_inicio(self):
        response = self.client.post(
            reverse('registro reserva', args=[self.habitacion.pk]),
            {
                'rut_huesped': '12345678-9',
                'fecha_inicio': '2026-12-03',
                'fecha_termino': '2026-12-01',
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertFalse(response.context['formulario'].is_valid())
        self.assertFalse(reservasModel.objects.exists())
