from django.db import models

# Create your models here.


class huspedModel(models.Model):
    rut = models.CharField(max_length=11, primary_key=True)
    nombre = models.CharField(max_length=50)
    telefono = models.CharField(max_length=50)
    def __str__(self):
        return f'{self.rut}'

class habitacionModel(models.Model):
    class tipos_habitacion(models.TextChoices):
        SINGLE = 'Single', 'Single'
        DOUBLE = 'Double', 'Double'
        TRIPLE = 'Triple', 'Triple'
        FAMILIAR = 'Familiar', 'Familiar'
    class imagenes_habitacion(models.TextChoices):
        ROOM1 = 'imagenes/room1.jpg', 'Room 1'
        ROOM2 = 'imagenes/room2.jpg', 'Room 2'
        ROOM3 = 'imagenes/room3.webp', 'Room 3'
        ROOM4 = 'imagenes/room4.jpg', 'Room 4'
        ROOM5 = 'imagenes/room5.jpg', 'Room 5'
        ROOM6 = 'imagenes/room6.jpg', 'Room 6'
        ROOM7 = 'imagenes/room7.jpg', 'Room 7'
        ROOM8 = 'imagenes/room8.jpg', 'Room 8'
        ROOM9 = 'imagenes/room9.jpg', 'Room 9'
        ROOM10 = 'imagenes/room10.webp', 'Room 10'
    imgen_habitacion = models.CharField(max_length=100, choices=imagenes_habitacion.choices, default='imagenes/default_room.jpg')
    numero_habitacion = models.CharField(max_length=3,primary_key=True)
    tipo_habitacion = models.CharField(max_length=90, choices=tipos_habitacion.choices,default=tipos_habitacion.SINGLE)
    descripcion_habitacion = models.TextField(default='Una habitacion muy comoda y acogedora, perfecta para descansar y relajarse.')
    precio_habitacion = models.IntegerField()
    class estados_habitacion(models.TextChoices):
        DISPONIBLE = 'Disponible', 'Disponible'
        OCUPADA = 'Ocupada', 'Ocupada'
        RESERVADA = 'Reservada', 'Reservada'
        MANTENCION = 'Mantencion', 'Mantencion'
    estado_habitacion = models.CharField(max_length=50, choices= estados_habitacion.choices,default=estados_habitacion.DISPONIBLE)
    def __str__(self):
        return f'Habitacion {self.numero_habitacion} - {self.tipo_habitacion} - {self.estado_habitacion}'



class reservasModel(models.Model):
    class estados_reserva(models.TextChoices):
        ACTIVA = 'Activa', 'Activa'
        FINALIZADA = 'Finalizada','Finalizada'
        CANCELADA = 'Cancelada','Cancelada'
    rut_huesped = models.ForeignKey(huspedModel,on_delete=models.CASCADE)
    numero_habitacion_reserva = models.ForeignKey(habitacionModel,on_delete=models.CASCADE)
    fecha_inicio = models.DateField()
    fecha_termino = models.DateField()
    estado_reserva = models.CharField(max_length=20, choices=estados_reserva.choices, default= estados_reserva.ACTIVA)
    def __str__(self):
        return f'Reserva de {self.rut_huesped.rut} - Habitacion {self.numero_habitacion_reserva.numero_habitacion} - Estado: {self.estado_reserva}'

