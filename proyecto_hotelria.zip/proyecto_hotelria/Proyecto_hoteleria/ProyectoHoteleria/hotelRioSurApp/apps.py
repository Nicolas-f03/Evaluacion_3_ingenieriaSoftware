from django.apps import AppConfig


class HotelriosurappConfig(AppConfig):
    name = 'hotelRioSurApp'
