from django import forms
from .models import reservasModel,habitacionModel, huspedModel

class huspedForm(forms.ModelForm):
    class Meta:
        model = huspedModel
        fields = [
            'rut',
            'nombre',
            'telefono'
            ]
        widgets = {
            'rut':forms.TextInput(attrs={
                'class':'form-control',
                'placeholder':'ingrese su Rut aqui'
            }),
            'nombre':forms.TextInput(attrs={
                'class':'form-control',
                'placeholder':'ingrese su nombre aqui'
            }),
            'telefono':forms.TextInput(attrs={
                'class':'form-control',
                'placeholder':'ingrese su telefono aqui'
            })
        }

class habitacionForm(forms.ModelForm):
    class Meta:
        model= habitacionModel
        fields= '__all__'


class reservaForm(forms.ModelForm):
    class Meta:
        model= reservasModel
        fields=[
            'rut_huesped',
            'fecha_inicio',
            'fecha_termino',
            ]
        widgets = {
            'rut_huesped':forms.TextInput(attrs={
                'class':'form-control',
                'placeholder':'ingrese su Rut aqui para hacer la reserva'
            }),
            'fecha_inicio': forms.DateInput(attrs={
                "type": "date"
            }),
            'fecha_termino': forms.DateInput(attrs={
                "type": "date"
            }),
        }

    def clean(self):
        cleaned_data = super().clean()
        fecha_inicio = cleaned_data.get('fecha_inicio')
        fecha_termino = cleaned_data.get('fecha_termino')

        if fecha_inicio and fecha_termino and fecha_termino <= fecha_inicio:
            self.add_error(
                'fecha_termino',
                'La fecha de término no puede ser igual o anterior a la fecha de ingreso.',
            )
        return cleaned_data


