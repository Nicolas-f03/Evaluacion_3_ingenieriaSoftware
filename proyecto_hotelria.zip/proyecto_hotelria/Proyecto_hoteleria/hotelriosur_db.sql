-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-11-2026 a las 20:32:18
-- Versión del servidor: 10.11.16-MariaDB
-- Versión de PHP: 8.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hotelriosur_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auth_group`
--

INSERT INTO `auth_group` (`id`, `name`) VALUES
(1, 'administradores');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auth_group_permissions`
--

INSERT INTO `auth_group_permissions` (`id`, `group_id`, `permission_id`) VALUES
(2, 1, 13),
(3, 1, 14),
(4, 1, 15),
(5, 1, 16),
(6, 1, 25),
(7, 1, 26),
(8, 1, 27),
(9, 1, 28),
(10, 1, 29),
(11, 1, 30),
(12, 1, 31),
(1, 1, 32);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 3, 'add_permission'),
(6, 'Can change permission', 3, 'change_permission'),
(7, 'Can delete permission', 3, 'delete_permission'),
(8, 'Can view permission', 3, 'view_permission'),
(9, 'Can add group', 2, 'add_group'),
(10, 'Can change group', 2, 'change_group'),
(11, 'Can delete group', 2, 'delete_group'),
(12, 'Can view group', 2, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add habitacion model', 7, 'add_habitacionmodel'),
(26, 'Can change habitacion model', 7, 'change_habitacionmodel'),
(27, 'Can delete habitacion model', 7, 'delete_habitacionmodel'),
(28, 'Can view habitacion model', 7, 'view_habitacionmodel'),
(29, 'Can add reservas model', 9, 'add_reservasmodel'),
(30, 'Can change reservas model', 9, 'change_reservasmodel'),
(31, 'Can delete reservas model', 9, 'delete_reservasmodel'),
(32, 'Can view reservas model', 9, 'view_reservasmodel'),
(33, 'Can add husped model', 8, 'add_huspedmodel'),
(34, 'Can change husped model', 8, 'change_huspedmodel'),
(35, 'Can delete husped model', 8, 'delete_huspedmodel'),
(36, 'Can view husped model', 8, 'view_huspedmodel');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$1500000$0VEkwU6WhNEodUsHC2966V$vzefF2mQxm9dnzxxUsJ8cEBcyThepCvLjOwVr/OkTTU=', '2026-11-15 19:02:02.675788', 1, 'DonHotelRioSur', '', '', 'info@hotelriosdelsur.com', 1, 1, '2026-11-15 15:46:45.397599'),
(2, 'pbkdf2_sha256$1500000$6cY2QZ4ZB4tkl9LAmUnmGR$HyebH+/QHf2dC5ivcy5uLonwRzyxKmCh/ZkVuC8sfFM=', '2026-11-15 15:51:32.570607', 0, 'administrador1', '', '', '', 0, 1, '2026-11-15 15:50:51.000000');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auth_user_groups`
--

INSERT INTO `auth_user_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2026-11-15 15:48:51.690207', '1', 'administradores', 1, '[{\"added\": {}}]', 2, 1),
(2, '2026-11-15 15:50:52.517408', '2', 'administrador1', 1, '[{\"added\": {}}]', 4, 1),
(3, '2026-11-15 15:51:00.848322', '2', 'administrador1', 2, '[{\"changed\": {\"fields\": [\"Groups\"]}}]', 4, 1),
(4, '2026-11-15 19:03:57.714053', '1', 'administradores', 2, '[]', 2, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(2, 'auth', 'group'),
(3, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(7, 'hotelRioSurApp', 'habitacionmodel'),
(8, 'hotelRioSurApp', 'huspedmodel'),
(9, 'hotelRioSurApp', 'reservasmodel'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2026-11-14 12:06:28.804027'),
(2, 'auth', '0001_initial', '2026-11-14 12:06:29.047411'),
(3, 'admin', '0001_initial', '2026-11-14 12:06:29.095572'),
(4, 'admin', '0002_logentry_remove_auto_add', '2026-11-14 12:06:29.100151'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2026-11-14 12:06:29.104744'),
(6, 'contenttypes', '0002_remove_content_type_name', '2026-11-14 12:06:29.148142'),
(7, 'auth', '0002_alter_permission_name_max_length', '2026-11-14 12:06:29.177649'),
(8, 'auth', '0003_alter_user_email_max_length', '2026-11-14 12:06:29.192783'),
(9, 'auth', '0004_alter_user_username_opts', '2026-11-14 12:06:29.197895'),
(10, 'auth', '0005_alter_user_last_login_null', '2026-11-14 12:06:29.223968'),
(11, 'auth', '0006_require_contenttypes_0002', '2026-11-14 12:06:29.225590'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2026-11-14 12:06:29.231058'),
(13, 'auth', '0008_alter_user_username_max_length', '2026-11-14 12:06:29.248709'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2026-11-14 12:06:29.264957'),
(15, 'auth', '0010_alter_group_name_max_length', '2026-11-14 12:06:29.281743'),
(16, 'auth', '0011_update_proxy_permissions', '2026-11-14 12:06:29.311360'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2026-11-14 12:06:29.333666'),
(18, 'hotelRioSurApp', '0001_initial', '2026-11-14 12:06:29.382295'),
(19, 'hotelRioSurApp', '0002_huspedmodel_alter_habitacionmodel_estado_habitacion_and_more', '2026-11-14 12:06:29.473992'),
(20, 'sessions', '0001_initial', '2026-11-14 12:06:29.494106'),
(21, 'hotelRioSurApp', '0003_habitacionmodel_descripcion_habitacion', '2026-11-14 12:42:30.646416'),
(22, 'hotelRioSurApp', '0004_habitacionmodel_imgen_habitacion', '2026-11-14 13:08:15.829353'),
(23, 'hotelRioSurApp', '0005_alter_habitacionmodel_imgen_habitacion', '2026-11-14 13:11:38.195481');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hotelriosurapp_habitacionmodel`
--

CREATE TABLE `hotelriosurapp_habitacionmodel` (
  `numero_habitacion` varchar(3) NOT NULL,
  `tipo_habitacion` varchar(90) NOT NULL,
  `precio_habitacion` int(11) NOT NULL,
  `estado_habitacion` varchar(50) NOT NULL,
  `descripcion_habitacion` longtext NOT NULL,
  `imgen_habitacion` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `hotelriosurapp_habitacionmodel`
--

INSERT INTO `hotelriosurapp_habitacionmodel` (`numero_habitacion`, `tipo_habitacion`, `precio_habitacion`, `estado_habitacion`, `descripcion_habitacion`, `imgen_habitacion`) VALUES
('123', 'Single', 12300, 'Disponible', 'Una habitacion muy comoda y acogedora, perfecta para descansar y relajarse.', 'imagenes/default_room.jpg'),
('402', 'Single', 10000, 'Reservada', 'Perfecta para la familia, una hermosa habitacion para relajarse despues de un dia largo de trabajo.', 'imagenes/room8.jpg'),
('404', 'Familiar', 20000, 'Reservada', 'Una habitacion muy comoda y acogedora, perfecta para descansar y relajarse.', 'imagenes/default_room.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hotelriosurapp_huspedmodel`
--

CREATE TABLE `hotelriosurapp_huspedmodel` (
  `rut` varchar(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `telefono` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `hotelriosurapp_huspedmodel`
--

INSERT INTO `hotelriosurapp_huspedmodel` (`rut`, `nombre`, `telefono`) VALUES
('21880788-7', 'Nicolas Ferreira', '+56 8982 8972');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hotelriosurapp_reservasmodel`
--

CREATE TABLE `hotelriosurapp_reservasmodel` (
  `id` bigint(20) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_termino` date NOT NULL,
  `estado_reserva` varchar(20) NOT NULL,
  `numero_habitacion_reserva_id` varchar(3) NOT NULL,
  `rut_huesped_id` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `hotelriosurapp_reservasmodel`
--

INSERT INTO `hotelriosurapp_reservasmodel` (`id`, `fecha_inicio`, `fecha_termino`, `estado_reserva`, `numero_habitacion_reserva_id`, `rut_huesped_id`) VALUES
(2, '2026-11-23', '2026-11-24', 'Activa', '404', '21880788-7');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indices de la tabla `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indices de la tabla `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indices de la tabla `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indices de la tabla `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indices de la tabla `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indices de la tabla `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indices de la tabla `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indices de la tabla `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indices de la tabla `hotelriosurapp_habitacionmodel`
--
ALTER TABLE `hotelriosurapp_habitacionmodel`
  ADD PRIMARY KEY (`numero_habitacion`);

--
-- Indices de la tabla `hotelriosurapp_huspedmodel`
--
ALTER TABLE `hotelriosurapp_huspedmodel`
  ADD PRIMARY KEY (`rut`);

--
-- Indices de la tabla `hotelriosurapp_reservasmodel`
--
ALTER TABLE `hotelriosurapp_reservasmodel`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hotelRioSurApp_reser_numero_habitacion_re_423307d9_fk_hotelRioS` (`numero_habitacion_reserva_id`),
  ADD KEY `hotelRioSurApp_reser_rut_huesped_id_770af4a5_fk_hotelRioS` (`rut_huesped_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de la tabla `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `hotelriosurapp_reservasmodel`
--
ALTER TABLE `hotelriosurapp_reservasmodel`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Filtros para la tabla `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Filtros para la tabla `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Filtros para la tabla `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Filtros para la tabla `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Filtros para la tabla `hotelriosurapp_reservasmodel`
--
ALTER TABLE `hotelriosurapp_reservasmodel`
  ADD CONSTRAINT `hotelRioSurApp_reser_numero_habitacion_re_423307d9_fk_hotelRioS` FOREIGN KEY (`numero_habitacion_reserva_id`) REFERENCES `hotelriosurapp_habitacionmodel` (`numero_habitacion`),
  ADD CONSTRAINT `hotelRioSurApp_reser_rut_huesped_id_770af4a5_fk_hotelRioS` FOREIGN KEY (`rut_huesped_id`) REFERENCES `hotelriosurapp_huspedmodel` (`rut`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
